﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_7___CS225
{
    /// <summary>
    /// This class creates a CaesarCipher object which allows you to perform Encryption and then
    /// Decryption on the input text.
    /// 
    /// It saves the encrypt/decrypt text to the text field and can return the text to the
    /// calling function.
    /// </summary>
    class CaesarCipher
    {
        //Fields
        private string text;
        private const int SHIFT = 2;
        private const string EMPTY_FILE_EXCEPTION_MSG = "ERROR: The File is Empty.";

        /// <summary>
        /// Properties
        /// </summary>
        public string Text
        {
            get { return text; }
            set
            {
                //Ensures the user is not trying to encrypt an empty file.
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentOutOfRangeException(EMPTY_FILE_EXCEPTION_MSG);
                }
                else
                {
                    text = value;
                }
            }
        }

        /// <summary>
        /// Constructor, takes a string, which is the file contents you want to encrypt/decrypt.
        /// </summary>
        /// <param name="input"></param>
        public CaesarCipher(string input)
        {
            Text = input;
        }

        //Methods

            /// <summary>
            /// Encrypts the text and then returns the encrypted text value.
            /// </summary>
            /// <returns></returns>
        public string Encrypt()
        {
            string cipherText = "";

            int length = Text.Length - 1;

            text = Text.ToLower();

            //Loops through each character in the text variable and will shift the character by 2.
            for (int i = 0; i <= length; i++)
            {
                char myChar = Text.ElementAt(i);

                //This if block make sure the alphabet loops around and assigns a lowercase 
                //alphabetical letter for each decrypted letter.
                if (myChar > 96 + SHIFT && myChar <= 122)
                {
                    myChar = Convert.ToChar(myChar - SHIFT);
                }
                else if (myChar > 96 && myChar <= 96 + SHIFT)
                {
                    myChar = Convert.ToChar(myChar + 26 - SHIFT);
                }
                cipherText = cipherText + myChar;

            }
            Text = cipherText;
            return cipherText;
        }

        /// <summary>
        /// Decrypts the text, and then returns the decrypted text value.
        /// </summary>
        /// <returns></returns>
        public string Decrypt()
        {
            string decodedText = "";
            int length = Text.Length - 1;

            text = Text.ToLower();
            
            //This for loop will go through each character in the text variable and shift the ascii code by 2.
            for (int i = 0; i < length; i++)
            {
                char myChar = Text.ElementAt(i);

                //This if block make sure the alphabet loops around and assigns a lowercase 
                //alphabetical letter for each encrypted letter.
                if (myChar > 96 && myChar <= 122 - SHIFT)
                {
                    myChar = Convert.ToChar(myChar + SHIFT);
                }
                else if (myChar > 122 - SHIFT && myChar <= 122)
                {
                    myChar = Convert.ToChar(myChar - 26 + SHIFT);
                }
                decodedText = decodedText + myChar;
            }
            Text = decodedText;
            return decodedText;
        }

    }
}
