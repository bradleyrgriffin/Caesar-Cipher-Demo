﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;


namespace Assignment_7___CS225
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        //Fields
        private string fileName;
        private CaesarCipher cipherObj;



        //Constructor
        public MainWindow()
        {
            InitializeComponent();
        }

        //Methods
        private void EnableButtons(bool enabled)
        {
            if (enabled)
            {
                encryptButton.IsEnabled = true;
                decryptButton.IsEnabled = true;
            }
            else
            {
                encryptButton.IsEnabled = false;
                decryptButton.IsEnabled = false;
            }
        }

        /// <summary>
        /// This menu item allows the user to open a file, and create a new CaesarCipher object. Which allows them the
        /// functionality to encrypt and decrypt the file.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OpenMenuItem_Click(object sender, RoutedEventArgs e)
        {
            //Open File
            string input;
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "My Documents";
            openFileDialog.Filter = "Text Files (.txt)|*.txt|All Files (*.*)|*.*";

            bool? userClickedOK = openFileDialog.ShowDialog();

            //This if statement makes sure the user has selected a file and selected Ok in the dialog box.
            if (userClickedOK == true)
            {
                fileName = openFileDialog.FileName;
                textBox.Clear();
                EnableButtons(false);

                //Opens the file and begins reading it. Also closes the file afterwards.
                using (StreamReader x = new StreamReader(@fileName))
                {

                    input = x.ReadToEnd();

                    //Allows the program to catch any exceptions and then print the result to the user.
                    try
                    {
                        cipherObj = new CaesarCipher(input);
                        textBox.AppendText(input);
                        EnableButtons(true);
                    }
                    catch(ArgumentOutOfRangeException y)
                    {
                        MessageBox.Show(y.Message);
                    }

                }
            }
        }

        /// <summary>
        /// This menu item saves allows the user to save the encrypted file to a new file, with their chosen name.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveMenuItem_Click(object sender, RoutedEventArgs e)
        {
            //Save File
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = "My Documents";
            saveFileDialog.Filter = "Text Files (.txt)|*.txt|All Files (*.*)|*.*";

            bool? userClickedOK = saveFileDialog.ShowDialog();

            //Makes sure the user has selected a location/file name and has selected Ok.
            if (userClickedOK == true)
            {
                fileName = saveFileDialog.FileName;
                File.WriteAllText(@fileName, textBox.Text);
            }
        }

        /// <summary>
        /// This menu item quits the program using the shutdown function.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void QuitMenuItem_Click(object sender, RoutedEventArgs e)
        {
            //Quit
            Application.Current.Shutdown();
        }

        /// <summary>
        /// This button Encrypts the text in the text box.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EncryptButton_Click(object sender, RoutedEventArgs e)
        {
            //Encrypt
            textBox.Clear();
            textBox.AppendText(cipherObj.Encrypt());
            //encryptButton.IsEnabled = false;
            //decryptButton.IsEnabled = true;
        }

        /// <summary>
        /// This button Decrypts the text in the text box.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DecryptButton_Click(object sender, RoutedEventArgs e)
        {
            //Decrypt
            textBox.Clear();
            textBox.AppendText(cipherObj.Decrypt());
            //decryptButton.IsEnabled = false;
            //encryptButton.IsEnabled = true;
        }
    }
}
